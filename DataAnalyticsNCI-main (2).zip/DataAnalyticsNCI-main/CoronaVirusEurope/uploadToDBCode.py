import requests
import pymongo
import shutil
import os
import pandas as pd
import zipfile
from urllib.request import urlopen
import dns
import requests
import json
from xml.etree.ElementTree import parse
import html
import numpy as np

path="./covidEuropeData/"
#Creates directory to store dataframes before uploading to database - AM
def directorySetup():
    if not os.path.isdir(path):
        try:
            os.mkdir(path)
        except OSError:
            print ("Creation of the directory %s failed" % path)
        else:
            print ("Successfully created the directory %s " % path)


#Function to download an xml file to the specified directory from a given URL
def pullXMLFromWeb(fileName,url,path):
    if ".xml" in url: 
        response = requests.get(url)
    else:
        response = requests.get(url+"xml/")

    with open(path+fileName+".xml","wb") as file:
            file.write(response.content)

#Function to download a json file to the specified directory from a given URL

def pullJSONFromWeb(fileName,url,path):
    if ".json" in url:
        response = requests.get(url)
    #elif ".xml" in url:
    #    pass
    else:
        response = requests.get(url+"json/")

    with open(path+fileName+".json","wb") as file:
            file.write(response.content)
        

# Lists and API Calls
#Contains the URLS that data is extracted from
def setupLists():
    global client,database_name,jsonDataTitlesAndUrls,xmlDataTitlesAndUrls,dataTitles,colsBedNumbersEurope,htmlDataTitlesAndUrls
    database_name="covidDataEurope"
    client = pymongo.MongoClient("mongodb+srv://kevinQuigley:drpxuux1Mvc9YZiV@cluster0.a0tmq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")

    jsonDataTitlesAndUrls=[["worldWideCasesAndDeaths","https://opendata.ecdc.europa.eu/covid19/nationalcasedeath/"],
                ["hospitalICURatesEurope","https://opendata.ecdc.europa.eu/covid19/hospitalicuadmissionrates/"]
                ]
    xmlDataTitlesAndUrls=[["hospitalBedDensity","https://apps.who.int/gho/athena/data/GHO/WHS6_102.xml?profile=simple&filter=COUNTRY:*;REGION:*"
                ]]
    
    htmlDataTitlesAndUrls=[["icuBedDensity","https://link.springer.com/article/10.1007/s00134-012-2627-8/tables/2"],
                           ["medianAge","https://worldpopulationreview.com/country-rankings/median-age"]]   #"https://en.wikipedia.org/wiki/List_of_countries_by_median_age"]]
                            #["GDP","https://www.worldometers.info/gdp/gdp-by-country/#:~:text=GDP%20by%20Country%20%20%20%20%23%20,%20%202.22%25%20%2022%20more%20rows%20"]]
#a link for GDP per capita is attached. maybe can use that if you want more comparisons.
    

    dataTitles=["hospitalICURatesEurope","worldWideCasesAndDeaths","hospitalBedDensity","icuBedDensity","medianAge"]
    colsBedNumbersEurope=["COUNTRY","GHO","PUBLISHSTATE","REGION","YEAR","Display","Numeric"]

#List needed to convert xml to a dataframe - AM
def xmlLists():
    global COUNTRY,GHO,PUBLISHSTATE,REGION,YEAR,Display,Numeric
    COUNTRY=[]
    GHO=[]
    PUBLISHSTATE=[]
    REGION=[]
    YEAR=[]
    Display=[]
    Numeric=[]

# Data Download Functions
#Before downloading the data, in the event of link expiry, we can use the mongo database

# Establing Connection

def testMongoDB():
    try:
        client = pymongo.MongoClient("mongodb+srv://kevinQuigley:drpxuux1Mvc9YZiV@cluster0.a0tmq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
        print("Connected successfully!!!")
        db = client.test  #db=client["covidEuropeData"]
    except:
        print("Could not connect to MongoDB")
        
#
#Checks if dataframes are already present in mongoDB -AM
#_update(client,dbName,collection, no_id)
def uncleanedDataDownload():
    setupLists()    
    database = client[database_name]
    collection = database.list_collection_names(include_system_collections=False)
    DBColNames=[]
    for collect in collection:
        DBColNames.append(collect)
    DBColNames.sort()
    dataTitles.sort()
    list_inter=list(set(DBColNames).intersection(set(dataTitles)))
    list_inter.sort()
    if list_inter == dataTitles:
        print("Dataframes already present in database. Dataframe pulling from database initiated.")
        MongoToDataFrame(client,database_name)
        #for collect in list_inter:
        #    MongoToDataFrame_update(client, database_name, collect, True)
    else:
        print("Dataframes not present in mongoDB. Upload to database initiated.")
        uploadDataframes()

def specificDataframeDownload(collection):
    setupLists()
    dbName=database_name
    no_id=True
    MongoToDataFrameSpecificDatabase(client,dbName,collection, no_id)
    
            
#Download dataframes from mongoDB
def MongoToDataFrame(client,dbName):
        """ Read from Mongo and Store into DataFrame """
        setupLists()
        global mongoCols
        global mongoDFs
        mongoCols=[]
        mongoDFs=[]
        db=client[dbName]
        for i in (dataTitles):
            mongoCols.append(db[i])
        for i in range(len(mongoCols)):
            mongoDFs.append(pd.DataFrame(list(mongoCols[i].find())))
        #removing id column
        for df in mongoDFs:
            for column in df.columns:
                if "_id" in column:
                    df.drop(column, axis = 1, inplace=True)
        print("Dataframes now stored as mongoDFs")
        return mongoDFs

#Uploads a dataframe to mongoDB
def write_df_to_mongoDB(  my_df,
                          database_name,
                          collection_name,
                          client,
                          chunk_size):
    #"""
    #This function take a list and create a collection in MongoDB (you should
    #provide the database name, collection, port to connect to the remoete database,
    #server of the remote database, local port to tunnel to the other machine)

    db = client[database_name]
    collection = db[collection_name]
    # To write
    collection.delete_many({})  # Destroy the collection
    #aux_df=aux_df.drop_duplicates(subset=None, keep='last') # To avoid repetitions
    my_list = my_df.to_dict("records")
    #my_df.drop_duplicates(inplace=True)
    #my_list=my_df.to_dict(orient="records")
    #my_list=my_df.to_mongo("records")
    l =  len(my_list)
    ran = list(range(l))
    steps=ran[chunk_size::chunk_size]
    steps.extend([l])

    # Inser chunks of the dataframe
    i = 0
    for j in steps:
        #print(j)
        collection.insert_many(my_list[i:j]) # fill de collection
        i = j

    print("Finished writing to MongoDB.")
    print("Download of dataframes from MongoDB now beginning.")
    MongoToDataFrame(client,database_name)
    return 


                    

#Converts files to appropriate dataframe format - AM
dataFrames=[]
def uploadDataframes():
    global dataFrames_xml,dataFrames_html,dataFrames_json
    directorySetup()
    setupLists()
    xmlLists()
    dataFrames_html=[]
    dataFrames_xml=[]
    dataFrames_json=[]

    #Downloads html files and converts them to dataframe - AM
    for i in range(len(htmlDataTitlesAndUrls)):
        dataFrames_html.append(pd.read_html(htmlDataTitlesAndUrls[i][1]))

    #Downloads xml files and converts them to dataframe - AM
    for j in range(len(xmlDataTitlesAndUrls)):
            pullXMLFromWeb(xmlDataTitlesAndUrls[j][0],xmlDataTitlesAndUrls[j][1],path)
            document=parse(path+xmlDataTitlesAndUrls[j][0]+".xml")
            
            for item in document.iterfind('Fact'):
                COUNTRY.append(item.findtext('COUNTRY'))
                GHO.append(item.findtext('GHO'))
                PUBLISHSTATE.append(item.findtext('PUBLISHSTATE'))
                YEAR.append(item.findtext('YEAR'))
                Display.append(item.findtext('Display'))
                Numeric.append(item.findtext('Numeric'))
    
            dataFrames_xml.append(pd.DataFrame({"Country": COUNTRY,"GHO":GHO, "PUBLISHSTATE":PUBLISHSTATE,
                        "YEAR":YEAR,"Display":Display,"Numeric":Numeric}))
    #Downloads json files and converts them to dataframe - AM
    for k in range(len(jsonDataTitlesAndUrls)):    
        pullJSONFromWeb(jsonDataTitlesAndUrls[k][0],jsonDataTitlesAndUrls[k][1],path)        
        dataFrames_json.append(pd.read_json(path+jsonDataTitlesAndUrls[k][0]+".json"))
        (dataFrames_json[k]).fillna("-",inplace=True)

    #Uploads json files to dataframe - AM
    for i in range(len(jsonDataTitlesAndUrls)):
         write_df_to_mongoDB(dataFrames_json[i],database_name,jsonDataTitlesAndUrls[i][0],client,100)
    #Uploads html files to dataframe - AM 
    for i in range(len(htmlDataTitlesAndUrls)):
         write_df_to_mongoDB(dataFrames_html[i][0],database_name,htmlDataTitlesAndUrls[i][0],client,100)
    #Uploads xml files to dataframe - AM
    for i in range(len(xmlDataTitlesAndUrls)):
         write_df_to_mongoDB(dataFrames_xml[i],database_name,xmlDataTitlesAndUrls[i][0],client,100)
        
    print("Data upload a success!!")
        
    
def MongoToDataFrameSpecificDataframe(client,dbName,collection, no_id):
    """ Read from Mongo and Store into DataFrame """
    query= {}
    print("Connecting to Mongo Database")
    print("Pulling dataframe from Mongo Database")
    # Make a query to the specific DB and Collection
    cursor = client[dbName][collection].find()

    # Expand the cursor and construct the DataFrame
    df =  pd.DataFrame(list(cursor))

    # Delete the _id
    if no_id:
        del df['_id']

    return df