import requests
import pymongo
import shutil
import os
import pandas as pd
import zipfile
from urllib.request import urlopen
import dns
import requests
import json
from xml.etree.ElementTree import parse
import html


path ="C:/Users/Andrew/Documents/Data analytics/semester 1/DB and analytics programming/assignment/Europe_data/"

document=parse(path+"/bedNumbersEurope.xml")

#def uploadFromXML
    
def csvWriter(fileName,url,path):
    r = requests.get(url, verify=False,stream=True)
    if r.status_code!=200:
        print ("Failure!!")
        exit()
    else:
        r.raw.decode_content = True
        with open(path+fileName+".csv", 'wb') as f:
            shutil.copyfileobj(r.raw, f)
        print("Success")

def pullXMLFromWeb(fileName,url,path):
    if ".xml" in url: 
        response = requests.get(url)
    else:
        response = requests.get(url+"xml/")

    with open(path+fileName+".xml","wb") as file:
            file.write(response.content)

def pullJSONFromWeb(fileName,url,path):
    if ".json" in url:
        response = requests.get(url)
    #elif ".xml" in url:
    #    pass
    else:
        response = requests.get(url+"json/")

    with open(path+fileName+".json","wb") as file:
            file.write(response.content)
        

#TODO Replace the lines below with the most recent API calls

# Lists and API Calls
def setupLists():
    global client,dataTitlesAndUrls,jsonDataTitlesAndUrls,xmlDataTitlesAndUrls,dataTitles,colsBedNumbersEurope,htmlDataTitlesAndUrls
    client = pymongo.MongoClient("mongodb+srv://kevinQuigley:drpxuux1Mvc9YZiV@cluster0.a0tmq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
    dataTitlesAndUrls=[["hospitalICURatesEurope","https://opendata.ecdc.europa.eu/covid19/hospitalicuadmissionrates/"],
                ["hospitalBedNumbersEurope","https://apps.who.int/gho/athena/data/GHO/WHS6_102.xml?profile=simple&filter=COUNTRY:*;REGION:*"],
                ["worldWideCasesAndDeaths","https://opendata.ecdc.europa.eu/covid19/nationalcasedeath/"]
                ]
    jsonDataTitlesAndUrls=[["hospitalICURatesEurope","https://opendata.ecdc.europa.eu/covid19/hospitalicuadmissionrates/"],
                ["worldWideCasesAndDeaths","https://opendata.ecdc.europa.eu/covid19/nationalcasedeath/"]
                ]
    xmlDataTitlesAndUrls=[["hospitalBedDensity","https://apps.who.int/gho/athena/data/GHO/WHS6_102.xml?profile=simple&filter=COUNTRY:*;REGION:*"
                ]]
    
    htmlDataTitlesAndUrls=[["icuBedDensity","https://link.springer.com/article/10.1007/s00134-012-2627-8/tables/2"],
                           ["medianAge","https://en.wikipedia.org/wiki/List_of_countries_by_median_age"]]

    

    dataTitles=["hospitalICURatesEurope","worldwide_cases_and_deaths","hospitalBedDensity","icuBedDensity","medianAge"]
    colsBedNumbersEurope=["COUNTRY","GHO","PUBLISHSTATE","REGION","YEAR","Display","Numeric"]

def xmlLists():
    global COUNTRY,GHO,PUBLISHSTATE,REGION,YEAR,Display,Numeric
    COUNTRY=[]
    GHO=[]
    PUBLISHSTATE=[]
    REGION=[]
    YEAR=[]
    Display=[]
    Numeric=[]

# Data Download Functions
#Before downloading the data, in the event of link expiry, we can use the mongo database

# Establing Connection

def testMongoDB():
    try:
        client = pymongo.MongoClient("mongodb+srv://kevinQuigley:drpxuux1Mvc9YZiV@cluster0.a0tmq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
        print("Connected successfully!!!")
        db = client["covidEuropeData"]
    except:
        print("Could not connect to MongoDB")

# connecting or switching to the database
client = pymongo.MongoClient("mongodb+srv://kevinQuigley:drpxuux1Mvc9YZiV@cluster0.a0tmq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
print("Connected successfully!!!")
db = client["covidEuropeData"]
def write_df_to_mongoDB(  my_df,
                          database_name,
                          collection_name,
                          client,
                          chunk_size):
    #"""
    #This function take a list and create a collection in MongoDB (you should
    #provide the database name, collection, port to connect to the remoete database,
    #server of the remote database, local port to tunnel to the other machine)

    db = client[database_name]
    collection = db[collection_name]
    # To write
    collection.delete_many({})  # Destroy the collection
    #aux_df=aux_df.drop_duplicates(subset=None, keep='last') # To avoid repetitions
    my_list = my_df.to_dict("records")
    l =  len(my_list)
    ran = list(range(l))
    steps=ran[chunk_size::chunk_size]
    steps.extend([l])

    # Inser chunks of the dataframe
    i = 0
    for j in steps:
        print(j)
        collection.insert_many(my_list[i:j]) # fill de collection
        i = j

    print("Done")
    return

#Trying to download the values straight from MongoDB if they are present
def dataDownload():
    setupLists()
    try:
        def MongoToDataFrame(client,dbName,collection, no_id):
            """ Read from Mongo and Store into DataFrame """
            query= {}
            db = client[dbName]
            print("Connecting to Mongo Database")
            # Make a query to the specific DB and Collection
            cursor = db[collection].find(query)

            # Expand the cursor and construct the DataFrame
            df =  pd.DataFrame(list(cursor))

            # Delete the _id
            if no_id:
                del df["_id"]

            return df

        MongoDataFrames=[]
        for i in range(len(dataTitlesAndUrls)+len(compressedFiles)):
            print("Downloading dataframe no.{}".format(i))
            MongoDataFrames.append( MongoToDataFrame(client,"covidEuropeData",dataTitles[i],True)) 
            MongoDataFrames[i].name=dataTitles[i]
            MongoDataFrames[i].to_csv ( path + dataTitles[i]+".csv", index = False, header=True)
        print("Data download from mongoDB A success!")
    #The following data downloads each url, and unzips if necessary
    except:
        print("Data not present on MongoDB, attempting download from source repo")
        for i in range(len(dataTitlesAndUrls)):
            if __name__ == "__main__":
                #csvWriter(dataTitlesAndUrls[i][0],dataTitlesAndUrls[i][1],path)
                #replacing kev's csvWriter with xml pulling
                pullXMLFromWeb(xmlDataTitlesAndUrls[i][0],xmlDataTitlesAndUrls[i][1],path)



        #need to put something in here for reading xmls/jsons
        dataFrames=[] 
        
        #for item in document.iterfind('Fact'):
        #    for i in range(len(colsBedNumbersEurope)):
        #        colsBedNumbersEurope[i].append(item.findtext(string(colsBedNumbersEurope[0])))

        #for i in range(len(colsBedNumbersEurope)):
        #    dataFrames.append = pd.dataFrames({colsBedNumbersEurope[i]})
            
        #dataFrames = pd.dataFrames({"Country": COUNTRY,"GHO":GHO, "PUBLISHSTATE":PUBLISHSTATE,
         #          "YEAR":YEAR,"Display":Display,"Numeric":Numeric})
        for i in range(len(jsonDataTitlesAndUrls)):            
            dataFrames.append(pd.read_json(path+dataTitlesAndUrls[i][0]+".json")) 
            dataFrames[i].name=jsonDataTitlesAndUrls[i][0]
        
        for i in range(len(xmlDataTitlesAndUrls)):
            document=parse(path+xmlDataTitlesAndUrls[i][0]+".xml")
            
            for item in document.iterfind('Fact'):
                COUNTRY.append(item.findtext('COUNTRY'))
                GHO.append(item.findtext('GHO'))
                PUBLISHSTATE.append(item.findtext('PUBLISHSTATE'))
                YEAR.append(item.findtext('YEAR'))
                Display.append(item.findtext('Display'))
                Numeric.append(item.findtext('Numeric'))
                
            dataFrames.append(pd.DataFrame({"Country": COUNTRY,"GHO":GHO, "PUBLISHSTATE":PUBLISHSTATE,
                               "YEAR":YEAR,"Display":Display,"Numeric":Numeric}))
            dataFrames[i+len(jsonDataTitlesAndUrls)].name=xmlDataTitlesAndUrls[i][0]

            

        for i in range(len(htmlDataTitlesAndUrls)):
                dataFrames.append(pd.read_html(htmlDataTitlesAndUrls[i][1]))
                dataFrames[i+len(jsonDataTitlesAndUrls)+len(xmlDataTitlesAndUrls)].name=htmlDataTitlesAndUrls[i][0]
            
             #Next we update the Mongo Database with the latest data pull
        for i in range(len(dataTitles)):
             write_df_to_mongoDB(dataFrames[i],"covidEuropeData",dataTitles[i],client,100)
    
            
        print("Data update and download success!")
        
def dataUpload():
    setupLists()
    xmlLists()
    for i in range(len(xmlDataTitlesAndUrls)):
        if __name__ == "__main__":
            pullXMLFromWeb(xmlDataTitlesAndUrls[i][0],xmlDataTitlesAndUrls[i][1],path)
    
    dataFrames=[] 
    for i in range(len(jsonDataTitlesAndUrls)):            
         dataFrames.append(pd.read_json(path+jsonDataTitlesAndUrls[i][0]+".json")) 
         dataFrames[i].name=jsonDataTitlesAndUrls[i][0]
     
    for i in range(len(xmlDataTitlesAndUrls)):
         document=parse(path+xmlDataTitlesAndUrls[i][0]+".xml")
         
         for item in document.iterfind('Fact'):
             COUNTRY.append(item.findtext('COUNTRY'))
             GHO.append(item.findtext('GHO'))
             PUBLISHSTATE.append(item.findtext('PUBLISHSTATE'))
             YEAR.append(item.findtext('YEAR'))
             Display.append(item.findtext('Display'))
             Numeric.append(item.findtext('Numeric'))
             
         dataFrames.append(pd.DataFrame({"Country": COUNTRY,"GHO":GHO, "PUBLISHSTATE":PUBLISHSTATE,
                            "YEAR":YEAR,"Display":Display,"Numeric":Numeric}))
         dataFrames[i+len(jsonDataTitlesAndUrls)].name=xmlDataTitlesAndUrls[i][0]
     
    for i in range(len(htmlDataTitlesAndUrls)):
        dataFrames.append(pd.read_html(htmlDataTitlesAndUrls[i][1]))
        dataFrames[i+len(jsonDataTitlesAndUrls)+len(xmlDataTitlesAndUrls)].name=htmlDataTitlesAndUrls[i][0]
    
     #Next we update the Mongo Database with the latest data pull
    for i in range(len(dataTitles)):
         write_df_to_mongoDB(dataFrames[i],"covidEurope",dataTitles[i],client,100)
         
    print("Data upload a success!!")
    
def mkDFs():
    setupLists()
    xmlLists()
    dataFrames_html=[]
    dataFrames_xml=[]
    dataFrames_json=[]
    
    for i in range(len(htmlDataTitlesAndUrls)):
        dataFrames_html.append(pd.read_html(htmlDataTitlesAndUrls[i][1]))
        print(htmlDataTitlesAndUrls[i][0])
        #dataFrames[i].name=htmlDataTitlesAndUrls[i][0]
        print(dataFrames_html)

    for j in range(len(xmlDataTitlesAndUrls)):
            pullXMLFromWeb(xmlDataTitlesAndUrls[j][0],xmlDataTitlesAndUrls[j][1],path)
            document=parse(path+xmlDataTitlesAndUrls[j][0]+".xml")
    
            for item in document.iterfind('Fact'):
                COUNTRY.append(item.findtext('COUNTRY'))
                GHO.append(item.findtext('GHO'))
                PUBLISHSTATE.append(item.findtext('PUBLISHSTATE'))
                YEAR.append(item.findtext('YEAR'))
                Display.append(item.findtext('Display'))
                Numeric.append(item.findtext('Numeric'))
    
            dataFrames_xml.append(pd.DataFrame({"Country": COUNTRY,"GHO":GHO, "PUBLISHSTATE":PUBLISHSTATE,
                        "YEAR":YEAR,"Display":Display,"Numeric":Numeric}))
            #print(dataFrames_xml)
            #dataFrames[i+len(htmlDataTitlesAndUrls)].name=xmlDataTitlesAndUrls[i][0]
            #print(xmlDataTitlesAndUrls[j][0])
    
    
    
    for k in range(len(jsonDataTitlesAndUrls)):            
        dataFrames_json.append(pd.read_json(path+jsonDataTitlesAndUrls[k][0]+".json")) 
        print(jsonDataTitlesAndUrls[k][0])
        
    
    