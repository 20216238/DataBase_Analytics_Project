# All functions in this file have been Authored by Kevin Quigley

import requests
import pymongo
import shutil
import os
import pandas as pd
import zipfile
from urllib.request import urlopen
import dns
import glob

#--------------------------Generic Functions------------------------

    
def csvWriter(fileName,url,path):
    r = requests.get(url, verify=False,stream=True)
    if r.status_code!=200:
        print ("Failure!!")
        exit()
    else:
        r.raw.decode_content = True
        with open(path+fileName+".csv", 'wb') as f:
            shutil.copyfileobj(r.raw, f)
        print("Success")



# Data Download Functions
#Before downloading the data, in the event of link expiry, we can use the mongo database

# connecting or switching to the database

def writeWikiToMongoDB(url,database,collection,client,tableNumberOnWikiPage):
    df_list = pd.read_html(url)
    ds.write_df_to_mongoDB(df_list[tableNumberOnWikiPage],database,collection,client,100)


def write_df_to_mongoDB(  my_df,
                          database_name,
                          collection_name,
                          client,
                          chunk_size):
    #"""
    #This function take a list and create a collection in MongoDB (We provide the database name
    # the client and the chunksize.)

    db = client[database_name]
    collection = db[collection_name]
    # To write
    collection.delete_many({})  # Destroy the collection
    my_list = my_df.to_dict('records')
    l =  len(my_list)
    ran = list(range(l))
    steps=ran[chunk_size::chunk_size]
    steps.extend([l])

    # Insert chunks of the dataframe
    i = 0
    for j in steps:
        print(j)
        collection.insert_many(my_list[i:j]) # fill the collection
        i = j
    print('Data upload to Mongo DB Complete')
    return


def MongoToDataFrame(client,dbName,collection, no_id):
    """ Read from Mongo and Store into DataFrame """
    query= {}
    print("Connecting to Mongo Database")
    # Make a query to the specific DB and Collection
    cursor = client[dbName][collection].find()

    # Expand the cursor and construct the DataFrame
    df =  pd.DataFrame(list(cursor))

    # Delete the _id
    if no_id:
        del df['_id']

    return df


# function to get unique values
def unique(list1):
 
    # intilize a null list
    unique_list = []
     
    # traverse for all elements
    for x in list1:
        # check if exists in unique_list or not
        if x not in unique_list:
            unique_list.append(x)
    # print list
    for x in unique_list:
        print(x),

#-----------------Korea Specific Functions--------------------

# Establing Connection

def testMongoDB():
    try:
        client = pymongo.MongoClient("mongodb+srv://kevinQuigley:drpxuux1Mvc9YZiV@cluster0.a0tmq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
        print("Connected successfully!!!")
        db = client["covidkoreadb"]
    except:
        print("Could not connect to MongoDB")

def unzipToCsv(path,url,filename):
    #open(path+"tmp",'tempfile.zip').close() 
    #os.mknod('./SouthKoreaDatasets/tmp/tempfile.zip')
    zipresp = urlopen(url)
    tempzip = open(path+"tmp/"+filename+".zip", "wb")
    tempzip.write(zipresp.read())
    tempzip.close()
    zf = ZipFile(path+"tmp/"+filename+".zip")
    zf.extractall(path = path)
    zf.close()


def directorySetup():
    if not os.path.isdir('./SouthKoreaDatasets'):
        try:
            os.mkdir(path)
        except OSError:
            print ("Creation of the directory %s failed" % path)
        else:
            print ("Successfully created the directory %s " % path)

            print ("Successfully created the directory %s " % path)

#TODO Replace the lines below with the most recent API calls

path ="./SouthKoreaDatasets"
# Lists and API Calls
def setupLists():
    global client,dataTitlesAndUrls,compressedFiles,dataTitles,Case,GDPTable,PatientInfo,Policy,Region,SearchTrend,Time,TimeAge,TimeGender,TimeProvince
    client = pymongo.MongoClient("mongodb+srv://kevinQuigley:drpxuux1Mvc9YZiV@cluster0.a0tmq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
    dataTitlesAndUrls=[["Case","https://storage.googleapis.com/kagglesdsdata/datasets/527325/1332417/Case.csv?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T174519Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=a51622f521dbfbd1ee90d3e95252ac94fa454784c95ddef0200932ac54bdc14696aabf89fe3c95a7c19c71df046d490e9edd919b0b087d6954653e8f48c2b68a6d73ff1fc5008fb1b64e4fc1a7109e6e49cc7e5708a6329ea1fc39bf5ed461b18e219331d9c70411847430fad6ebb0ac053841e2caec74d49c4af85fed534254c0bfb8d4ee5a8f328c42ce12e0605b26e127bbb33cc36bd2d382c4d448e62e90ee7d473c134dd0f62c8c63f87894d5765cc319fd144571459f06f5a46d580141d5850c7ea1642e1639bfcdbd97efdead351aa1c7c8b522687bed53a6caa6234e9de32b3dcd64d68dcb63a554c5ac68d63effd3be702dd155c3cb14c22266d2f5"],
                ["PatientInfo","https://storage.googleapis.com/kagglesdsdata/datasets/527325/1332417/PatientInfo.csv?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T164842Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=9bd0209ed4cec079a426c86bf937336d9cf74459cc9106a16ed244537ded938298a8ded3f761929447f81f30f6683279afd6a465025f847734876bcdbb1d8d1d2c61a7f547fc0489090e1e72c69f588b7a7f7e1a9a0703589974e8a3a5ed91bd9596db1ed64b8960e1d0a2d5b117c542c8cd7d6b1da4151ff34b44b51fc62b76220c61e1cf15aa17c8a44e54becda141a236c8e15903a48e279b2fc4abf801924e5ad24619f37bbd85f07f177d7874384e5605723cac4364293adcb0992c04293c6734999978ac358acf61b0746f6b28f1c3797b91db0d4e95931a5d9834962654ad572b0b7ec41afaa40a0bc29bac4064764bf23a509fd96e60c368c2481a4d"],
                ["Policy","https://storage.googleapis.com/kagglesdsdata/datasets/527325/1332417/Policy.csv?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180857Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=a5e6c543e925adea8276f1e1d1fdd1690687f6b095cfdceef9833fdfda827f7e8d84f967edeffb0943991dbc34ef44655b06374a5cc4c79b78a224ddeb3263aaa0cd9c3e16da62f67c5f5b45ce02bcea13a9623956037f820a608e88dbb05364dd89a6551d7919cb332c98a69b4b00330eeb197156461404f2eb1e43b63d2a110739540e5985914e3a7738c69af4c88f75812adcc39a6207f1dab68afd4e4259c001a798792bf2506fcc32c3cfe9a9a8ce1795e3ead7fa930dbbca97c317a2fd0cece534f495333c12a31724c93d4ba9e023fa27658a8658fb4f3ce75696d4180f28aa3992c1e43a7709714e3b400f3a6591ba7398ea2853509ffa189450ff34"],
                ["Region","https://storage.googleapis.com/kagglesdsdata/datasets/527325/1332417/Region.csv?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180901Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=2c414fe1a80f6dd4592c7ffa5a742fed862c6c418530e06ea08b4abd9112869f6f3ac969c11f761a7b27d40cbca6cb8ee52b4ca2930cbc291103c82f018c3f248845c9f0a1f2457a1848ca2fac586e380e9eeb7cf89bbce002d2417b4fcd2c936817a8f29822815443c88458d492e550da02ae45885bbddb9eb500ea3ecbbab532b3723974d2d3461315c6dc0c6413894956b78f7cda327247b0d540eb34976d93e4e15039510bdcf7a1c6edd47b030635977ade89a16c2e744e6ae648d30dd3c6f782a2fbfa993c5ac6288582fae21f093b23845cede683765b4541eabd76914e51488d0caf8556f68338387e1b1c4664a823f9d581264d138b94951634aa12"],
                ["SearchTrend","https://storage.googleapis.com/kagglesdsdata/datasets/527325/1332417/SearchTrend.csv?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180906Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=74354a5b12c5f8c5bb95751fb689a3eb62113cec0eb83134b2ed2e21f44a220a8bf6e56f0065ebdda81d742d4744821acff8e6e43a967d0e663d4d0dcd235d87a2dcee0de4c252bcd21614151a35f56f413b1ed99560afe1933e566c450d5e4208d4c9add40f49703936bac34c765b1b90fb85d5b6f0987e10e4ad2e078688fab572d6be0d11d8347f0bfa1efee711ed350c5e07082a1ee364c74978d7546ea8670b6c2c5599a5adb5213c0cbdd62d40b85918628ba56e92070c01cbae24d76022e14c8607ddb61cbc42758fc2e6429b9389cca9c6cb8b77a10a02fbaae587caf6d4906dacc60cb2b6ccff1b261ffff1d9d43e8abf838ffee12c26e6c00fa28d"],
                #["SeoulFloating","https://storage.googleapis.com/kaggle-data-sets/527325/1332417/compressed/SeoulFloating.csv.zip?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180913Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=32a417246043803d26677a6fc869692a7d0a610802cfaa14e7ebcb865f596c98ec677130b574948fe6b4e08954567068b1cb9d8abfacceccd11371bdef3ca9b4f799e63b8ebde18992e79c00a7a9666b538fe18c48520b2e3cb95afb924cdb80089b56964d1c55c4b1f9afa65477b0da6bd5a637873a63e77acc67cdad9a1590197bf288073dd9733a57157756820c0637b2e6d05a96a7407aa0551cc5611c47771ac801326675397f26cb1e531e720924b5b2b080b5d5c31b916a8f18630af235b617e4bc66df4ba50a775aa1acae85ec34d224798dff3736b83011e6a3d7439eb449ddc7277557dd8ed0a3897230116c0cdd5229db95082e8bdf0866693a4c"],
                ["Time","https://storage.googleapis.com/kagglesdsdata/datasets/527325/1332417/Time.csv?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180919Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=5d959a0fcf08d904468eb463587f4b92f10dee693b6d66c76be4be5d32593ad4c7cdf1e62f5b65c5f697f8fbc74aaf9a78db24bfdccc3d95300ce526fadb6ad65850884e8778a54da12266d609aecd8df824c2069598da310319189ece67cf95fe0b1f7d9094f71a25247b3459fa35224746e847499bbbdb511d4a543209db0dcfbf0f283b1b5334130043d3475d44734f2c2d1f6500bb15084e4e05a008b7437bf0f46a916db21c17cd051104acfb38092672f261274769464032b09b2450338cba27a81a7304141890dda32fa28a44395ebca3ae57ee59bff431748a5ebe1d3a17a7dc9fa441cd3994991c39a3c47ba54085d36e32b6fe639dde1676bb6377"],
                ["TimeAge","https://storage.googleapis.com/kagglesdsdata/datasets/527325/1332417/TimeAge.csv?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180926Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=1dfe6bafffb5b396cc9b688e55331a71bbfb617de3af1cf33be8be09ff9b31963668ae2391f9d30787e4beb646aba59e8879a4ec19f7b2e803045ee2d292afdfd6cd0b16bb411a1900e64d9b11c0573279ccf7ce040f4abd790a43927d092ecb7b2af8b2a23e091dfe2e3e6b6e64290c051eab927752c1b968ad2663ee214dbb60efa3353dc0bf6e09fc0b69c56f9eec1074bba99142eda05dbb13f15ebc817a743c9ff2e99e84c0cbd259e58fbc1ab28767357cbe09d628825a20d0d511ee89ebfd26d29b9f6cc51cd557bd2370fbc46a67145b21c296f8fe3481d4e38e10cc58a0fb2c5698e7065a2316f793a7c33724c0d31e036cade836e77c2cab044f53"],
                ["TimeGender","https://storage.googleapis.com/kagglesdsdata/datasets/527325/1332417/TimeGender.csv?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180931Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=70b609b7156947e946fdc6f90794338327ce9c253678a287e7f7697f73dfe273e59f2ddceb157215ef6ed060b4fc7538e7041b65cc3d6085cbab95b6eccdb2e9cf9dd33dbf37f9d9c1674f442b6066aadfe75a24e4e5a1d70013f82afd2b392d5a4af564272d255f0775bef8c57199a5ce688620215df4b684294892b60f84937f6afbcd226f86c1aed99c330ac692b6bc4ef1fb7a51efe15f927b1847673fc2e6667684a58119a4d79f1641fadeb827fa5587db0f84359ef046beda66c1106436e62b0fcfd1ad2af232251600d0c9dfa796488708b6cb62003c9f8a340fccf68e167d9a81c13ad5249e4a094ce96a3969348d4dca86bce35512b83e361bf4a2"],
                ["Weather","https://storage.googleapis.com/kaggle-data-sets/527325/1332417/compressed/Weather.csv.zip?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180948Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=7adc6f83f236862e5429104013ec7a850020fcb4602df64b6e1fe1febfc78ae6d165c7460cfc72dbe28480c3809ad9d90310c2772f8061f70cb4e5aa141d280d3f4607afdc8c8f9ae412e8b30f89ac6d527bb3867dc628cf756dfa9041394c6e0552176778df85ee36839c272064670dc1d53f0999bf7e9a70a0598ecd1b9eca6c7cc30b2d2e5f48e4032d93e305108f7a35c608618ec9aecf30fedbc354667ce36b023b593a1219c72dd62dfad9ccc083e25a49ab5667da3dcd3fc00c4903f26a8efef4a0db0112296efe0c196f309ab262777068108672a427cd12cb7796919708d43e7886d91ef7e0f8d4148688fa5fbe3b2dbd0e2db02648cf9c807cf8ad"],
                ["TimeProvince","https://storage.googleapis.com/kagglesdsdata/datasets/527325/1332417/TimeProvince.csv?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180938Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=7ecebe234a6cb81fa645470b979905ef6e5dc5530fb0e9b9ef34a16dced39638f62d3952e4346d481981e0abee3039510e290e285ea849680aa1da6f9024e3d43dae42317407712d29e5ec23a74837048f8df1f79a125a4ed3538400ab3041fdc29f58b3977d619ab6a509c632858a4887a9902328f63ec70f5b9f6f9d25d9c4778fbd752fbd28440738e579da017419a232c73fd8d7046859eee40ee0d4492c9bce636bec391bc54a25f9cb7ccae559c7fbeb922acea6a8da92a58571d79eafb57062d1404d9571e4bcdae4b28367e24d3400462b4bb47ddd9e0138055b492140cf1fdd3794e6175ed194a90fb92e69b48e6db260f877e4deec1bfff9ca1f8a"]]

    compressedFiles=[["SeoulFloating","https://storage.googleapis.com/kaggle-data-sets/527325/1332417/compressed/SeoulFloating.csv.zip?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180913Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=32a417246043803d26677a6fc869692a7d0a610802cfaa14e7ebcb865f596c98ec677130b574948fe6b4e08954567068b1cb9d8abfacceccd11371bdef3ca9b4f799e63b8ebde18992e79c00a7a9666b538fe18c48520b2e3cb95afb924cdb80089b56964d1c55c4b1f9afa65477b0da6bd5a637873a63e77acc67cdad9a1590197bf288073dd9733a57157756820c0637b2e6d05a96a7407aa0551cc5611c47771ac801326675397f26cb1e531e720924b5b2b080b5d5c31b916a8f18630af235b617e4bc66df4ba50a775aa1acae85ec34d224798dff3736b83011e6a3d7439eb449ddc7277557dd8ed0a3897230116c0cdd5229db95082e8bdf0866693a4c"],
                ["Weather","https://storage.googleapis.com/kaggle-data-sets/527325/1332417/compressed/Weather.csv.zip?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210327%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210327T180948Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=7adc6f83f236862e5429104013ec7a850020fcb4602df64b6e1fe1febfc78ae6d165c7460cfc72dbe28480c3809ad9d90310c2772f8061f70cb4e5aa141d280d3f4607afdc8c8f9ae412e8b30f89ac6d527bb3867dc628cf756dfa9041394c6e0552176778df85ee36839c272064670dc1d53f0999bf7e9a70a0598ecd1b9eca6c7cc30b2d2e5f48e4032d93e305108f7a35c608618ec9aecf30fedbc354667ce36b023b593a1219c72dd62dfad9ccc083e25a49ab5667da3dcd3fc00c4903f26a8efef4a0db0112296efe0c196f309ab262777068108672a427cd12cb7796919708d43e7886d91ef7e0f8d4148688fa5fbe3b2dbd0e2db02648cf9c807cf8ad"]]


    dataTitles=["Case","PatientInfo","Policy","Region","SearchTrend","Time","TimeAge","TimeGender","TimeProvince","Weather","SeoulFloating"]


def writeAdditionalDataToMongoDB():
    writeWikiToMongoDB("https://en.wikipedia.org/wiki/List_of_South_Korean_regions_by_GDP","covidkoreadb","GDPByRegion",client,1)

def downloadWikiTableFromMongoDB():
    global GDPTable
    GDPTable=MongoToDataFrame(client,"covidkoreadb","GDPByRegion",False)
    if not os.path.isfile(path+'/GDPTable.csv'):
        GDPTable.to_csv ( path +'/GDPTable.csv', index = False, header=True)

def koreaDataSetup():
    print("Checking if data is present on local machine")
    directorySetup()


def koreaDataDownload():
    global Case,GDPTable,PatientInfo,Policy,Region,SearchTrend,Time,TimeAge,TimeGender,TimeProvince,Weather 
    setupLists()
    csvDataFrames=[]
    try:
        if os.path.isdir('./SouthKoreaDatasets'):
            print("\nData is present on local machine as CSVs. \n\nWriting csv to dataframe")
            files = glob.glob(path+"/*.csv")
            for f in files:
                csv = pd.read_csv(f)
                csvDataFrames.append(csv)
            
            Case=           csvDataFrames[0]
            GDPTable =      csvDataFrames[1]
            PatientInfo=    csvDataFrames[2]
            Policy=         csvDataFrames[3]
            Region =        csvDataFrames[4]
            SearchTrend=    csvDataFrames[5]
            Time =          csvDataFrames[6]
            TimeAge=        csvDataFrames[7]
            TimeGender=     csvDataFrames[8]
            TimeProvince=   csvDataFrames[9]
            Weather=        csvDataFrames[10]
            print("Data read from local csv success! ")

        else: 
            print("\n")
            raise Exception("Data read from csv failed. Attempting rewrite from online")
    except:
        try:
            print("\nTrying to download the values straight from MongoDB if they are present")
            directorySetup()
            MongoDataFrames=[]
            # We can download the tables using two methods. 
    
            # The first way, the data is to download to a local csv file, which can then be read back 
            for i in range(len(dataTitlesAndUrls)+len(compressedFiles)-2):
                print("Downloading dataframe no.{}".format(i))
                MongoDataFrames.append( MongoToDataFrame(client,"covidkoreadb",dataTitles[i],True)) 
                MongoDataFrames[i].name=dataTitles[i]
                MongoDataFrames[i].to_csv ( path +'/' + dataTitles[i]+".csv", index = False, header=True)
            
            #Naming the dataframes
            Case=           MongoDataFrames[0]
            PatientInfo=    MongoDataFrames[1]
            Policy=         MongoDataFrames[2]
            Region =        MongoDataFrames[3]
            SearchTrend=    MongoDataFrames[4]
            Time =          MongoDataFrames[5]
            TimeAge=        MongoDataFrames[6]
            TimeGender=     MongoDataFrames[7]
            TimeProvince=   MongoDataFrames[8]
            Weather=        MongoDataFrames[9]
            #SeoulFloating= MongoDataFrames[10]
            #Removing the final two dataframes greatly increases data download speeds  
    
            print("\nDownloading additional html tables")
            downloadWikiTableFromMongoDB()
            print("\nData download from mongoDB A success!\n")
    
        #If for any reason, the data isn't present on Mongo DB, it can be read into python, then re-uploaded to mongoDB by executing the lines below
        except:
            try:
                print("Data not present on MongoDB, attempting download from source repo")
                for i in range(len(dataTitlesAndUrls)):
                    if __name__ == '__main__':
                        csvWriter(dataTitlesAndUrls[i][0],dataTitlesAndUrls[i][1],path)
        
                from zipfile import ZipFile
        
                for i in range(len(compressedFiles)):
                    if __name__ == '__main__':
                        unzipToCsv(path,compressedFiles[i][1],compressedFiles[i][0])
        
                dataFrames=[] 
                for i in range(len(dataTitlesAndUrls)+len(compressedFiles)):
                    dataFrames.append( pd.read_csv(path+"/"+dataTitles[i]+".csv")) 
                    dataFrames[i].name=dataTitles[i]
        
                #Next we update the Mongo Database with the latest data pull
                for i in range(len(dataTitlesAndUrls)+len(compressedFiles)):
                    write_df_to_mongoDB(dataFrames[i],"covidkoreadb",dataTitles[i],client,100)
        
                #Entering the tables 
                Case=dataFrames[0]
                PatientInfo=dataFrames[1]
                Policy=dataFrames[2]
                Region = dataFrames[3]
                SearchTrend=dataFrames[4]
                Time = dataFrames[5]
                TimeAge=dataFrames[6]
                TimeGender=dataFrames[7]
                TimeProvince=dataFrames[8]
                Weather=dataFrames[9]
                #SeoulFloating=dataFrames[10]
                #Removing the final two dataframes greatly increases data download speeds 
                #Lastly, we download the additional HTML tables from the source
                writeAdditionalDataToMongoDB()
        
                print("Data update and download success!")
            except:
                print("Uh oh, looks like the download links have expired")

